package com.example.eyeonwaterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Forgetpassword1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgetpassword1);
    }
}