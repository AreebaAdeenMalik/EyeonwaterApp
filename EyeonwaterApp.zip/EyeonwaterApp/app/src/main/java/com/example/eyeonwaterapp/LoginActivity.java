package com.example.eyeonwaterapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class LoginActivity extends AppCompatActivity {

    EditText loginusername, loginpassword;
    Button loginbutton, regbutton, forgetbtn;
    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginusername = findViewById(R.id.username);
        loginpassword = findViewById(R.id.password);
        loginbutton = findViewById(R.id.loginbtn);
        regbutton = findViewById(R.id.registerbtn);

        forgetbtn = findViewById(R.id.button);
        database = FirebaseDatabase.getInstance();

        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!validateUsername() | !validatePassword()){

                }else {
                    checkUser();
                }
            }
        });

        regbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
               startActivity(intent);
            }
        });
    }

    public void txtSignInForgotPasswordClicked(View v){
        Intent intent = new Intent(this, Forgetpassword.class);
        startActivity(intent);
    }
    public Boolean validateUsername(){
        String val = loginusername.getText().toString();
        if (val.isEmpty()){
            loginusername.setError("Username cannot be empty");
            return false;
        }else {
            loginusername.setError(null);
            return true;
        }
    }
    public Boolean validatePassword(){
        String val = loginpassword.getText().toString();
        if (val.isEmpty() || val.length() < 6){
            loginpassword.setError("Please enter at least 6 characters");
            return false;
        }else {
            loginpassword.setError(null);
            return true;
        }
    }

    public void checkUser()
    {
        String userUsername = loginusername.getText().toString().trim();
        String userPassword = loginpassword.getText().toString().trim();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");
        Query checkUserDatabase = reference.orderByChild("username").equalTo(userUsername);

        checkUserDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if ((snapshot.exists())){
                    loginusername.setError(null);
                    String passwordFromDB = snapshot.child(userUsername).child("password").getValue(String.class);

                    if (!Objects.equals(passwordFromDB, userPassword)){
                        loginusername.setError(null);
                        Intent intent = new Intent(LoginActivity.this, Home1Activity.class);
                        startActivity(intent);
                    }else {
                        loginpassword.setError("Invalid Credentials");
                        loginpassword.requestFocus();
                    }
                }else {
                    loginusername.setError("User does not exist");
                    loginusername.requestFocus();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}