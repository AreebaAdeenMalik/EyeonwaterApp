package com.example.eyeonwaterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.example.eyeonwaterapp.databinding.ActivityHistory1Binding;

public class History1Activity extends DrawerBaseActivity {

    ActivityHistory1Binding activityHistory1Binding;
    ActivityHistory1Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityHistory1Binding = ActivityHistory1Binding.inflate(getLayoutInflater());
        setContentView(activityHistory1Binding.getRoot());
        allocateActivityTitle("History");

    }
}